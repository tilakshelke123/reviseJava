package Day4;

public class CustomExceptionDemo {


	public static void main(String[] args) {
		try {
			int age=16;
			if(age<18) {
				throw new CustomExcption("Your under the age of 18..!");
			}
		
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}finally {
			System.out.println("code exicuted...");
		}

	}

}
