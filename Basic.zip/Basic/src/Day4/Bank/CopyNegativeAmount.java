package Day4.Bank;

public class CopyNegativeAmount extends Exception {

	public CopyNegativeAmount(String msg) {
		super(msg);
	}
}
