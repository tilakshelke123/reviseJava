package Day4.Bank;

public class BankTester {


	public static void main(String[] args) {
		BankAccount b=new BankAccount();  
		BankAccount b1 = new BankAccount("Tilak", 1234, 10000);
		BankAccount b2=new BankAccount("Mrunali",1235,20000);
	
		try {
			
			b1.Display();
			double bal = b1.deposit(2000);
			System.out.println("bal after deposit: " + bal);
			
			double bal2 = b1.withdraw(20000);
			System.out.println("bal after withdraw: " + bal2);
			
			b.transfAmount( b1, b2,200);
			
		} catch (NegativeAmount e) {

			System.out.println(e.getMessage());
			System.out.println("please enter valid amount");
		}

	}

}
