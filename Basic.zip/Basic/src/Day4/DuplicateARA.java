package Day4;

import java.util.Scanner;

public class DuplicateARA {

	

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		
		int arr[]= {1,2,1,3,4,2,1};
		
		int distinct[]=new int[arr.length];
		
		int k=0;
		
		for(int i=0;i<arr.length;i++) {
			boolean found=false;
			for(int j=0;j<arr.length;j++) {
				if(arr[i]==distinct[j]) {
					found= true;
					break;
				}
			}
			if(!found) {
				distinct[k++]=arr[i];
				
			}
			
		}
		int newarr[]=new int[k];
		for(int i=0;i<k;i++) {
		 newarr[i]=distinct[i];
			System.out.print(" " +newarr[i]);
		}
		
	}

}
