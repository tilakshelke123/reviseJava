package Day5.vehicleInterface;

public class Bicycle implements Vehicle{

	@Override
	public void startEngine() {
		System.out.println("Bicycle Engine Started ");
		
	}

	@Override
	public void stopEngine() {
		System.out.println("Bicycle Engine Stopped ");
		
	}

	public  static int getTopSpeedLimit(int speed) {
		return speed;
		
	}
}
