package Day5;

public interface IRbi {
	
	public abstract void calculaleEMI();
	
	public static void linkwithAdhar() {
		System.out.println("Link your mobile no with aadhar");
	}

}
