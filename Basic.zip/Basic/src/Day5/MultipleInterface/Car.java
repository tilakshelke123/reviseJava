package Day5.MultipleInterface;

public class Car implements Vehicle {

	@Override
	public void startEngine() {
		System.out.println("Car Engine  Started ");
		
	}

	@Override
	public void stopEngine() {
		System.out.println("Car Engine  Stopped ");
		
	}
	public  static int getTopSpeedLimit(int speed) {
		return speed;
		
	}

}
