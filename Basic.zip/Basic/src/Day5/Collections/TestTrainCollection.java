package Day5.Collections;

import java.util.ArrayList;

public class TestTrainCollection {

	public static void main(String[] args) {
		ArrayList<Train> tlist = new ArrayList<Train>();

		Train t1 = new Train(1, "Amravati Express", "Amravati", "nagpur");
		Train t2 = new Train(2, "Mharashtra Express", "pune", "gondia");
		Train t3 = new Train(3, "kachiguda Express", "mumbai", "wardha");
		Train t4 = new Train(4, "Nanded Panvel ", "nanded", "panvel");
		Train t5 = new Train(5, "Mahalaxmi ", "mumbai ", "kolhapur");

		// addint the data into
		tlist.add(t1);
		tlist.add(t2);
		tlist.add(t3);
		tlist.add(t4);
		tlist.add(t5);

		//
		System.out.println("before");
		// printing the data
		for (Train t : tlist) {
			System.out.println(t);

		}
//		System.out.println("after by object and index ");
//		// remove element by index
//		tlist.remove(t3); // by object
//	
//		tlist.remove(0); // by index
//
//		for (Train t : tlist) {
//			System.out.println(t);
//
//		}
//		
		// add Cancelled train in the list
		ArrayList<Train> Clist = new ArrayList<Train>();
		Clist.add(t5);
		Clist.add(t4);
		System.out.println("all canclled trains");
		for (Train t : Clist) {
			System.out.println(t);
		}
		
		System.out.println("cancelled train from main tlist");
		tlist.removeAll(Clist);
		
		for (Train t : tlist) {
			System.out.println(t);
		}
		
		//newly added trains 
		ArrayList<Train> morelist = new ArrayList<Train>();
		morelist.add(t4);
		morelist.add(t5);
		Train t6 = new Train(6, "pune danapur ", "pune ", "varanasi");
		morelist.add(t6);
		
		//extra trains only 
		System.out.println("added new trains ");
		for (Train t : morelist) {
			System.out.println(t);
		}
		
		tlist.addAll(morelist);
		System.out.println("add more trains in main  tlist ");
		for (Train t : tlist) {
			System.out.println(t);
		}
		

	}
}
