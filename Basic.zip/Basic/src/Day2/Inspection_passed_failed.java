package Day2;

import java.util.Scanner;

public class Inspection_passed_failed {
	// int[][] arr;

	public int countFullyPassedBatches(int[][] results) {
		// this.arr[4][5] = results;
		int countRow = 0;

		for (int i = 0; i < 4; i++) {
			int countCol = 0;

			for (int j = 0; j < 5; j++) {
				if (results[i][j] == 1) {
					countCol++;
					
				}
			}

			if (countCol == 5) {
				countRow++;

			}
			System.out.println("");
		}
		
		return countRow;
		

	}

	public static void main(String[] args) {
		Inspection_passed_failed obj = new Inspection_passed_failed();
		Scanner sc = new Scanner(System.in);
		int r = 4;
		int c = 5;
		int results[][] = new int[r][c];

		System.out.println("Entere the values for  2 d array ");
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				System.out.println("Enter the only 0 and 1 for row " + i + ":");
				results[i][j] = sc.nextInt();

			}
		}
		int count = obj.countFullyPassedBatches(results);
		System.out.println("count" + count);
	}

}
