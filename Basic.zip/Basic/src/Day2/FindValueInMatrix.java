package Day2;

import java.util.Scanner;

public class FindValueInMatrix {
	public void FindVMatrix() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the row and column");
		int n = sc.nextInt();
		int p[][] = new int[n][n];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				System.out.println("Enter value:");
				p[i][j] = sc.nextInt();
			}

		}
		System.out.println("Enetr value which has to be find in Matrix:");
		int v = sc.nextInt();

		// search
		boolean found = false;
		
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (p[i][j] == v) {
					System.out.println("[" + (i + 1) + "," + (j + 1) + "]");
					found=true;
				}
				
			}
			if(found==true) {
				System.out.println("element found="+v);
				break;
			}
			else {
				System.out.println("Element not found= "+v);
				break;
			}
		}

	}

	public static void main(String[] args)  {
		FindValueInMatrix mat = new FindValueInMatrix();
		
		mat.FindVMatrix();
		
	}

}
