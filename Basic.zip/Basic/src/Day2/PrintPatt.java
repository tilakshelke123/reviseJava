package Day2;

import java.util.Scanner;

public class PrintPatt {

//	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter the row and colimn");
//		int n = sc.nextInt();
//		int p[][] = new int[n][n];
//		for (int i = 0; i < n; i++) {
//			for (int j = 0; j < n; j++) {
//				System.out.println("Enter value:");
//				p[i][j] = sc.nextInt();
//			}
//
//		}
//		for (int i = 0; i < n; i++) {
//			for (int j = 0; j < n; j++) {
//				if (i == j) {
//					System.out.println(p[i][j]);
//				}
//			}
//		}
//
//	}
	
	public static void main(String[] args) {
		Scanner sc =  new Scanner(System.in);
		System.out.println("Enter the row and col");
		System.out.println(" plz take both as same ");
		System.out.println("Enter the row ");
		int r =sc.nextInt();
		System.out.println("Enter the col ");
		int c = sc.nextInt();
		
		int matrix[][] =  new int [r][c];
		//for enetering thevalue into array 
		for(int i = 0 ;i <r ;i++) {
			for(int j = 0 ;j<c;j++) {
				System.out.println("enter the vale :");
				matrix[i][j]=sc.nextInt();
			}
		}
		// for printing the value 
		for(int i = 0 ;i <r ;i++) {
			for(int j = 0 ;j<c;j++) {
				if(i==j) {
				System.out.println(matrix[i][j]);
				}else {
					System.out.println("*");
				}
			}
		}
	}

}
