package Day2;

import java.awt.geom.Arc2D.Float;
import java.util.Scanner;

public class Array2D {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int  r,c =5;
		System.out.println("enter number of Student: ");
		r=sc.nextInt();
		int marks[][]=new int[r][c];
		
		 
		for(int i=0;i<r;i++) {
			
			 for(int j=0;j<5;j++) {
				 System.out.println("Enter the Marks of student:"+(i+1));
				 marks[i][j]=sc.nextInt();
			 }
		}
		
		for(int i=0;i<r;i++) {
			int sum=0;
			 for(int j=0;j<5;j++) {
				 System.out.println("Marks of Student "+(i+1)+" in Subject:"+(j+1)+":"+marks[i][j]);
				sum=sum+marks[i][j];
			 	}
				System.out.println("Total marks of Student "+(i+1)+": "+sum);
				
				System.out.println("Percentage: "+(sum/5));
			 
			}
			
		}

	}
	