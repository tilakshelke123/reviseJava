package Day3;

import java.util.Scanner;

public class Student extends Person {

	int rno;
	int marks;

	public Student(int rno, String name, int marks) {
		super(name);
		this.rno = rno;
		this.marks = marks;
	}

	public void Display() {
		System.out.println("Roll no :-" + rno);
		super.Display();
		// System.out.println("name");
		System.out.println("marks :-" + marks);
	}
	
	public void waliking() {
		System.out.println("Student is Walking>>>>>");
	}
	
	
	public static void main(String[] args) {
		/*
		 * ** part1 **
		 * 
		 * Student s1 = new Student(1, "Mrunali", 99); s1.Display(); Student s2 = new
		 * Student(2, "Pragati", 0 ); s2.Display();
		 ** 
		 * part1 end **
		 */
		
		// input from user
		Scanner sc = new Scanner(System.in);

		// declare array and size
		Student stud[] = new Student[5];

		// intyitalize and taking input array and store
		for (int i = 0; i < 5; i++) {
			System.out.println("Enter the Stundent information like rollno,name,marks:");
			stud[i] = new Student(sc.nextInt(), sc.next(), sc.nextInt());

		}
		// 1 way to display
		// dsiplay array object data  by using " simple for loop "
		for (int i = 0; i < 5; i++) {
			System.out.println("Stundent information  rollno:" + (i + 1));
			stud[i].Display();

		}
		
	/*	// extra implementations 
		// 2 way to display 
		// dsiplay array object data  by using " ForEach loop "
		///
				for (Student s : stud) {
				//	System.out.println("Stundent information  rollno:" + (i + 1));
					s.Display();

				}
    */
		for(Student s : stud) {
			s.waliking();             
		}
	}
		

}
