package Day3.poly;

public class Employee {

	int empNo;
	String name;
	String Dept;
	double salary;
	
	
	public Employee(int empNo, String name, String dept, double salary) {
		super();
		this.empNo = empNo;
		this.name = name;
		Dept = dept;
		this.salary = salary;
	}
	
	// add method that Calculate Salary 
	public void CalSalary () {
		
		System.out.println("Employee Salary :"+salary);
		
	}

	public void Display() {
		System.out.println("empNo: "+empNo+" name:"+name+" dept:"+Dept+" salary:"+salary);
	}

}
