package Day3.poly;

public class Manager extends Employee {

	double incentives;
	int teamSize;

	public Manager(int empNo, String name, String dept, double salary, double  bonus, int teamSize) {
		super(empNo, name, dept, salary);
		this.incentives = bonus;
		this.teamSize=teamSize;
	}

	// add method that Calculate Managers Salary
	public void CalSalary () {
		System.out.println("manager salary :"+(salary+incentives));
		
		
	}
	public void Display() {
		System.out.println("empNo: "+empNo+" name:"+name+" dept:"+Dept+" salary:"+salary+" incentives:"+incentives+" teamSize:"+teamSize);
	}
	
	public void assignTask() {
		System.out.println("Manager Assign Task...");
	}
}
