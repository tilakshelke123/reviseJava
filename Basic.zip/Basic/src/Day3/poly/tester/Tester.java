package Day3.poly.tester;

import Day3.poly.Devloper;
import Day3.poly.Employee;
import Day3.poly.Manager;

public class Tester {

	public static void main(String[] args) {

		Employee e1 = new Employee(1, "Mrunali", "Cs", 150);
		Employee e2 = new Employee(2, "Pragati", "Electric", 100);

		Manager m1 = new Manager(3, "Tilak", "Civil", 100, 500, 4);
		Manager m2 = new Manager(4, "Vivk", "bca", 100, 400, 4);
		
		Devloper d1=new Devloper(5, "manoj", "It", 150,"Java",1);
		Devloper d2=new Devloper(6, "Vish", "It", 250,"Python",2);

		Employee emp[] = { e1, e2, m1, m2 ,d1,d2};

		/*//Extra  way to define & assign 
		 * Employee emp [] = new Employee[4]; 
		 * emp[0]=e1;
		 * emp[1]=e2;
		 * emp[2]=m1;
		 * emp[3]=m2;
		 */

		for (Employee e : emp) {
			e.Display();
//			e.CalSalary();
			
			//  instanceOf to call self method .
			if(e instanceof Manager) {
				((Manager) e).assignTask(); // downCasting 
			}
			if(e instanceof Devloper) {
				((Devloper) e).resolveBug(); // downCasting 
			}
		}
	}

}
