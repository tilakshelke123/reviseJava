package Day3.poly;

public class Devloper extends Employee{

	
	String skills;
	int exp;
 
	public Devloper(int empNo, String name, String dept, double salary,String skills,int exp) {
		super(empNo, name, dept, salary);
		this.skills=skills;
		this.exp=exp;
	}
	
	public void CalSalary () {
		System.out.println("Devloper salary :"+(salary));
		
		
	}
	public void Display() {
		System.out.println("empNo: "+empNo+" name:"+name+" dept:"+Dept+" salary:"+salary);
	}
	
	public void resolveBug() {
		System.out.println("Devloper Resolve the bug..");
	}
}
