package Day3;

public class Person {
	String name;
	int Age;
	String city;

	public Person(String name, int age, String city) {
		super();
		this.name = name;
		Age = age;
		this.city = city;
	}

	public Person(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void Display() {
		System.out.println("name:- " + name);
	}

	public void waliking() {
		System.out.println("Person is Walking>>>>>");
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", Age=" + Age + ", city=" + city + "]";
	}

}
