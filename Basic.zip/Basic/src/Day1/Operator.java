package Day1;

public class Operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=5;
		System.out.println(i++);
		System.out.println(++i);
		System.out.println(++i+i++);
		System.out.println(i++ + ++i);
	}

}
