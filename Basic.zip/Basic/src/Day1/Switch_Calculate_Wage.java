package Day1;

import java.util.Scanner;

public class Switch_Calculate_Wage {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enetr no month as Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec: ");
		String month = sc.next();
		System.out.println("enter year:");
		int year=sc.nextInt();
		int totalSal;

		switch (month) {

		case "Jan":

			totalSal = 31 * 600;
			System.out.println("salary of jan is " + totalSal);
			break;
		case "Feb":
			System.out.println("enter year:");
			 year = sc.nextInt();
			if (year % 4 == 0) {
				totalSal = 28 * 600;
				System.out.println("salary of labour feb is " + totalSal);
			} else {
				totalSal = 29 * 600;
				System.out.println("salary of feb is " + totalSal);
			}
			break;
		case "Mar":
			totalSal = 31 * 600;
			System.out.println("salary of March is " + totalSal);
			break;
		case "Apr":
			totalSal = 30 * 600;
			System.out.println("salary of Apr is " + totalSal);
			break;
		case "May":
			totalSal = 31 * 600;
			System.out.println("salary of May is " + totalSal);
			break;
		case "Jun":
			totalSal = 30 * 600;
			System.out.println("salary of Jun is " + totalSal);
			break;
		case "Jul":
			totalSal = 31 * 600;
			System.out.println("salary of July is " + totalSal);
			break;
		case "Aug":
			totalSal = 31 * 600;
			System.out.println("salary of Aug is " + totalSal);
			break;
		case "Sep":
			totalSal = 30 * 600;
			System.out.println("salary of Sep is " + totalSal);
			break;

		case "Oct":
			totalSal = 31 * 600;
			System.out.println("salary of Oct is " + totalSal);
			break;
		case "Nov":
			totalSal = 30 * 600;
			System.out.println("salary of Nov is " + totalSal);
			break;
		case "Dec":
			totalSal = 31 * 600;
			System.out.println("salary of Dec is " + totalSal);
			break;

		default:
			System.out.println("Yor enter Wrong month...!!");
		}
	
		
	
	}
}
