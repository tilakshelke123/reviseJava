package day8.map;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class tester {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		Student S = new Student();
		// we are creating the list of markls for each diff students for mrunali , tilak
		// , piyush
		List<Integer> mmarks = new ArrayList<Integer>();
		mmarks.add(65);
		mmarks.add(50);
		mmarks.add(95);
		mmarks.add(74);
		mmarks.add(99);

		List<Integer> Tmarks = new ArrayList<Integer>();
		Tmarks.add(99);
		Tmarks.add(98);
		Tmarks.add(95);
		Tmarks.add(74);
		Tmarks.add(99);

		List<Integer> pmarks = new ArrayList<Integer>();
		pmarks.add(96);
		pmarks.add(98);
		pmarks.add(95);
		pmarks.add(74);
		pmarks.add(99);

		List<Integer> Vmarks = new ArrayList<Integer>();
		Vmarks.add(99);
		Vmarks.add(98);
		Vmarks.add(95);
		Vmarks.add(500);
		Vmarks.add(99);

		List<Integer> PRmarks = new ArrayList<Integer>();
		PRmarks.add(99);
		PRmarks.add(101);
		PRmarks.add(95);
		PRmarks.add(200);
		PRmarks.add(99);

		List<Integer> Mmarks = new ArrayList<Integer>();
		Mmarks.add(99);
		Mmarks.add(101);
		Mmarks.add(95);
		Mmarks.add(200);
		Mmarks.add(99);

		// we are creating the
		Student s1 = new Student(123, "Mrunali", mmarks);
		Student s2 = new Student(456, "Tilak", Tmarks);
		Student s3 = new Student(111, "piyush", pmarks);
		Student s4 = new Student(222, "vivk", Vmarks);
		Student s5 = new Student(333, "pragati", PRmarks);

		Map<String, Student> mainmapStudent = new HashMap<>();
		mainmapStudent.put("1", s1);
		mainmapStudent.put("2", s2);
		mainmapStudent.put("3", s3);

		mainmapStudent.put("2", s1); // key are always unique but value getting override

		mainmapStudent.put("3", s3); // only values override not key

		mainmapStudent.put("6", s3);// new key added

		Map<String, Student> mapStudent = new HashMap<>();
		mapStudent.put("4", s4);
		mapStudent.put("5", s5);

		// NORMAL display the
		System.out.println(mainmapStudent);
		System.out.println("-------------------");
		System.out.println(mapStudent);
		System.out.println("-------------------");

		// CUSTOM FOR LOOP for mainMapStudent
		for (Map.Entry<String, Student> entry : mainmapStudent.entrySet()) {
			System.out.println("key:" + entry.getKey() + " " + "value:" + entry.getValue());
		}
		System.out.println("-------------------");

		System.out.println("implement mapStudent");
		// CUSTOM FOR LOOP for mapStudent
		for (Map.Entry<String, Student> entry : mapStudent.entrySet()) {
			System.out.println("key:" + entry.getKey() + " " + "value:" + entry.getValue());
		}
		System.out.println("-------------------");

		// Implements putAll
		System.out.println("implement putAll");
		mainmapStudent.putAll(mapStudent);
		// CUSTOM FOR LOOP for mapStudent
		for (Map.Entry<String, Student> entry : mainmapStudent.entrySet()) {
			System.out.println("key:" + entry.getKey() + " " + "value:" + entry.getValue());
		}
		System.out.println("-------------------");

		// remove by key
		mainmapStudent.remove("6");
		mainmapStudent.remove("2");
		System.out.println("remove by key");
		for (Map.Entry<String, Student> entry : mainmapStudent.entrySet()) {
			System.out.println("key:" + entry.getKey() + " " + "value:" + entry.getValue());
		}
		System.out.println("-------------------");

		/*
		 * mapStudent.replace(s4); System.out.println("remove by value as object"); for
		 * (Map.Entry<String, Student> entry : mapStudent.entrySet()) {
		 * System.out.println("key:" + entry.getKey() + " " + "value:" +
		 * entry.getValue()); } System.out.println("-------------------");
		 */

		Student s7 = new Student(789, "Manoj", Mmarks);
		mapStudent.replace("5", s7);

		System.out.println("replaceby key value ");
		for (Map.Entry<String, Student> entry : mapStudent.entrySet()) {
			System.out.println("key:" + entry.getKey() + " " + "value:" + entry.getValue());
		}
		System.out.println("-------------------");

		
		
		// simple way to to display percentage
		System.out.println("--------------------------------");
		for (Map.Entry<String, Student> entry : mainmapStudent.entrySet()) {
			int sum = 0;
			for (int i : entry.getValue().getMarks()) {
				sum += i;
			}
			System.out.println("Prn:" + entry.getKey() + " " + "percentage:" + (sum / 4) + "%");
		}
		
		System.out.println("---------------------------------------------------------"
				+ ""
				+ ""
				+ ""
				+ ""
				+ ""
				+ ""
				+ ""
				+ ""
				+ ""
				+ ""
				+ "---------------------------------------------------------------------------------");
		
		
		
		System.out.println("-------------------");

		System.out.println("-------------------");
		System.out.println("-------------------");

		System.out.println("-------------------");
		System.out.println("-------------------");

		
		// extra time pass mrunali start

		System.out.println("enter the key  of  student, who percentage want to calculate: ");

		String key = sc.next();
		calPercentage(key, mainmapStudent);

	}

	// mrunalis extra time pass working well ! good Mrunali
	// if you want to calaculate specific student percentage then used this
	public static void calPercentage(String key, Map<String, Student> mainmapStudent) {

		for (Map.Entry<String, Student> entry : mainmapStudent.entrySet()) {
			if (key.equals(entry.getKey())) {
				int sum = 0;
				for (int i : entry.getValue().getMarks()) {
					sum += i;
				}
				System.out.println("Prn:" + entry.getKey() + " " + "percentage:" + (sum / 4) + "%");
			}
		}

	}

}
