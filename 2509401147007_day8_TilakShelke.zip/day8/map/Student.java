package day8.map;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Student {
  private  int pnr;
   private String name;
    List<Integer> marks;
    
	public Student() {
		super();
	}

	public Student(int pnr, String name, List<Integer> marks) {
		super();
		this.pnr = pnr;
		this.name = name;
		
		this.marks = marks;
	}
    
	public Student(int pnr, String name) {
		super();
		this.pnr = pnr;
		this.name = name;
		this.marks = new ArrayList<Integer>();
	}

	public int getPnr() {
		return pnr;
	}

	public void setPnr(int pnr) {
		this.pnr = pnr;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Integer> getMarks() {
		return marks;
	}

	public void setMarks(List<Integer> marks) {
		this.marks = marks;
	}

	@Override
	public String toString() {
		return "Student [pnr=" + pnr + ", name=" + name + ", marks=" + marks + "]";
	}
	
	
	
    
}
