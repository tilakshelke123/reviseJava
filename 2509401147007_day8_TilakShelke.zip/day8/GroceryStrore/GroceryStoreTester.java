package day8.GroceryStrore;

import java.util.HashMap;
import java.util.Locale.Category;

import day8.map.Student;

import java.util.Map;
import java.util.Scanner;

public class GroceryStoreTester {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		Map<String, Double> ItemName1 = new HashMap<String, Double>();
		ItemName1.put("Apple", 60.00);
		ItemName1.put("banana", 50.00);
		ItemName1.put("kiwi", 70.00);
		
		Map<String, Double> ItemName2 = new HashMap<String, Double>();
		ItemName2.put("Milk", 70.00);
//		Map<String, Double> ItemName3 = new HashMap<String, Double>();
//		ItemName3.put("flower", 80.00);
//		Map<String, Double> ItemName4 = new HashMap<String, Double>();
//		ItemName4.put("shirt", 90.00);
//		Map<String, Double> ItemName5 = new HashMap<String, Double>();
//		ItemName5.put("table", 100.00);
//		Map<String, Double> ItemName6 = new HashMap<String, Double>();
//		ItemName6.put("pen", 50.00);

		Map<String, Map<String, Double>> grocesry = new HashMap<String, Map<String, Double>>();

		grocesry.put("fruit", ItemName1);
		grocesry.put("Dairy", ItemName2);
//		grocesry.put("Vegtables", ItemName3);
//		grocesry.put("cloths", ItemName4);
//		grocesry.put("furniture", ItemName5);
//		grocesry.put("Stationary", ItemName6);

//		System.out.println(grocesry.);
		// CUSTOM FOR LOOP for mainMapStudent
		for (Map.Entry<String, Map<String, Double>> entry : grocesry.entrySet()) {
			System.out.println("Category:" + entry.getKey() + " " + "Item:" + entry.getValue());
		}
		System.out.println("------------------------------------------------------");

		// check the item first by containskey if found then add
		System.out.println("Enetr the category name which want to add:");
		String category=sc.next();
		System.out.println("enter the item:");
		String item=sc.next();
		System.out.println("enter the Price:");
		double Price=sc.nextDouble();
		
			if (grocesry.containsKey(category)) {
				ItemName1.put("Orange", 60.00);
				grocesry.put("fruit", ItemName1);

			}
			else {
				Map<String, Double> ItemName3 = new HashMap<String, Double>();
				ItemName3.put(item, Price);
				grocesry.put(category, ItemName3);
			}
		
		//just printing the data
		for (Map.Entry<String, Map<String, Double>> entry : grocesry.entrySet()) {
			System.out.println("Category:" + entry.getKey() + " " + "Item:" + entry.getValue());
		}
		System.out.println("------------------------------------------------------");
		
		//To get the price of item
		System.out.println("Enetr the category name which want to add:");
		String category2=sc.next();
		System.out.println("Enter the item:");
		String Item2=sc.next();
		if(grocesry.containsKey(category2)) {
			if(ItemName1.containsKey(Item2)) {
				for (Map.Entry<String,  Double> entry : ItemName1.entrySet()) {
					System.out.println("price" + entry.getValue());
				}
			
			}
			else if(ItemName2.containsKey(Item2)) {
				for (Map.Entry<String,  Double> entry : ItemName2.entrySet()) {
					System.out.println("price" + entry.getValue());
				}
			}
			else {
					System.out.println("item not present.");
				}
			
			
		}
		
		
		
	}
}