package day8.Sort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TestSorting {

	public static void main(String[] args) {
		List<Prtoduct> product = new ArrayList<Prtoduct>();
		product.add(new Prtoduct(5, "Boat Headphones", 6000));
		product.add(new Prtoduct(1, "Laptop Headphones", 76000));

		product.add(new Prtoduct(2, "Iphone Headphones", 145000));

		product.add(new Prtoduct(3, "Ipad Headphones", 44000));

		product.add(new Prtoduct(4, "Boat 	Earphone", 2000));

		product.add(new Prtoduct(7, "Charging Cables", 600));
		product.add(new Prtoduct(6, "Mouse", 900));

		for (Prtoduct p : product) {
			System.out.println(p);

		}
		System.out.println("-------------------------------------");
		Collections.sort(product);
		
		for (Prtoduct p : product) {
			System.out.println(p);
	}
		
		product.stream().sorted().forEach(System.out::println);

}
}