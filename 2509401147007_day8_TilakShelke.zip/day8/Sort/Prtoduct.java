package day8.Sort;

public class Prtoduct implements Comparable<Prtoduct> {

	int id ;
	String name;
	double price;
	
	public Prtoduct(int id, String name, double price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}

	@Override
	public String toString() {
		return "Prtoduct [id=" + id + ", name=" + name + ", price=" + price + "]";
	}

	
	
	// must be implemented "compareTo" when you used sort and also implments Comparable Interface at class level 
//	@Override
//	public int compareTo(Prtoduct o) {
//		
//		return Integer.compare(this.id, o.id);
//	}
	
	
	@Override
	public int compareTo(Prtoduct o) {
		
		return this.name.compareTo( o.name);
	}
	
	
	
}
