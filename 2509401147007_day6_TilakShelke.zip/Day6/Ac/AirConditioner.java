package Day6.Ac;

import java.util.ArrayList;

public class AirConditioner {
	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	String brand;
	double price;
	private int temp;
	int warrantyYear;

	ArrayList<AirConditioner> aclist = new ArrayList<AirConditioner>();

	public AirConditioner(String brand, double price, int warrantyYear) {
		super();
		this.brand = brand;
		this.price = price;
		this.temp = 16;
		this.warrantyYear = warrantyYear;
	}

	public int getTemp() {
		return temp;
	}

	public void setTemp(int temp) {
		this.temp = temp;
	}

	@Override
	public String toString() {
		return "AirConditioner [brand=" + brand + ", price=" + price + ", temp=" + temp + ", warrantyYear="
				+ warrantyYear + "]";
	}

	public void add(AirConditioner e) {
		aclist.add(e);
	}

	public AirConditioner() {
		super();

	}

	public void display() {
		System.out.println("Display list of AC:");
		for (AirConditioner a : aclist) {
			System.out.println(a);
		}
		System.out.println("-------------------------------");
	}

	public void add(int b, AirConditioner e) {
		for (int i = 0; i < aclist.size(); i++) {
			if (i == b) {
				aclist.add(i, e);
			}
		} 

	}
	
	public void remove(int b) {
		for (int i = 0; i < aclist.size(); i++) {
			if (i == b) {
				aclist.remove(i);
			}
			
		} 
		System.out.println("-------------------------------");
	}

	public void newaddAll(ArrayList<AirConditioner> newList) {
		aclist.addAll(newList);
		for(AirConditioner b:aclist) {
			System.out.println(b);
		}
		System.out.println("-------------------------------");
		
	}

	public void removeSab(ArrayList<AirConditioner> newList) {
	
		aclist.removeAll(newList);
		for(AirConditioner b:aclist) {
			System.out.println(b);
		}
		System.out.println("remove new list Successfully");
		System.out.println("-------------------------------");
	}

	public void setprice(AirConditioner ac3) {
		setPrice(5000);
		
	}

	public void setprice(String brand2) {
		for(AirConditioner b:aclist) {
			boolean found=false;
			while(!found) {
//			if(b.brand.contains(brand2)) {
			if(b.brand.equals(brand2)) {
				b.setPrice(100000);
				System.out.println("update price of brand..:"+b.brand);
				System.out.println(b);
				found=true;
				break;
			}
			else {
	System.out.println("Brand not exit...");
				break;
				
				}
			}
			continue;
		}
			
		}
	

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	

}
