package Day6.Ac;

import java.util.ArrayList;
import java.util.Scanner;

public class AcTester {
//String brand, double price, int temp, int warrantyYear
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ArrayList<AirConditioner> newList = new ArrayList<AirConditioner>();
		AirConditioner a=new AirConditioner();
		
		AirConditioner ac1 = new AirConditioner("LG", 30000,10);
		AirConditioner ac2 = new AirConditioner("samsung", 40000, 5);
		AirConditioner ac3= new AirConditioner("ifb", 80000, 7);
		AirConditioner ac4= new AirConditioner("voltas", 80000, 7);
		
		AirConditioner ac5= new AirConditioner("panasonic", 80000, 7); 
		AirConditioner ac6= new AirConditioner("daikin", 80000, 7); 
		AirConditioner ac7= new AirConditioner("Carrier", 80000, 7); 
		
		
		
		
		//add
		a.add(ac1);
		a.add(ac2);
		a.add(ac3);
		a.add(ac4);
		a.display();
		
		
		//add at index
		a.add(1, ac4);
		a.display();
		
		//remove
		a.remove(1);
		a.display();
		
		
		// newList add
		
		newList.add(ac5);
		newList.add(ac6);
		newList.add(ac7);
	
		//printnew list
		for(AirConditioner n :newList) {
			System.out.println(n);
		}
		System.out.println(" add new list in old list");
		a.newaddAll(newList);
		
		//remove all
		System.out.println(" remove new list");
		a.removeSab(newList);
		
		
		//update by using setter
		System.out.println("update by using setter");
		System.out.println("Enter Brand name:");
		String brand;
		brand=sc.next();
		a.setprice(brand);

	}

}
