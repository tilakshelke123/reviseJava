package Day4.Bank;

public class CopyBank {

	public int accNo;
	public String userName;
	public double balAcc;

	public CopyBank(int accNo, String string, double balAcc) {
		super();
		this.accNo = accNo;
		this.userName = string;
		this.balAcc = balAcc;
	}

	public double deposit(double amount) {
		balAcc = balAcc + amount;
		return balAcc;
	}

	public double withdrawl(double amount) {
		balAcc = balAcc - amount;
		return balAcc;

	}
	
	void Display () {
		System.out.println("Name:"+userName+ " UserAccount:"+accNo+" Balance:"+balAcc);
	}
}