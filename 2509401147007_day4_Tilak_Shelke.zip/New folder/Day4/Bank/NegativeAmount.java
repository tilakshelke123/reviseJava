package Day4.Bank;

public class NegativeAmount extends Exception{

	public NegativeAmount(String Message) {
		super(Message);
	}

}
