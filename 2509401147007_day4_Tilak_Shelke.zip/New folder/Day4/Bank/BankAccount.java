package Day4.Bank;

public class BankAccount {
	
	String name;
	int accNo;
	double balance;
	
	public BankAccount() {
		super();
	}

	public BankAccount(String name, int accNo, double balance) {
		
		this.name = name;
		this.accNo = accNo;
		this.balance = balance;
	}
	
	public void Display() {
		System.out.println("name: "+name +" accNo: "+accNo+" balance:"+balance);
		
	}
	public void transfAmount(BankAccount b1,BankAccount b2,double amount) throws NegativeAmount{
		double balB1=b1.withdraw(amount);
		double balB2=b2.deposit(amount);
		System.out.println("Amount withdraw from acoount :"+b1.accNo+" is:"+amount+" cureent balance is: "+balB1);
		System.out.println("Amount deposit from acoount :"+b2.accNo+" is:"+amount+" cureent balance is: "+balB2);
	}
	
	
	public double deposit(double amount) {
		System.out.println("Current  bal before deposit: "+balance);
		System.out.println("Current Deposit Amount is : "+amount);
		balance=balance+amount;
		System.out.println("now bal is:"+balance);
		
		return  balance;
	}
	
	public double withdraw(double amount) throws NegativeAmount {
		System.out.println("Current  bal before Withdrawl: "+balance);
		System.out.println("Current Withdrawing Amount is : "+amount);
		if(amount<balance) {
		balance=balance-amount;
		}
		else {
			throw new NegativeAmount("We Dont have such suffiecint balance");
		}
		System.out.println("Now bal is: "+ balance);
		return  balance;
	}
	

}
