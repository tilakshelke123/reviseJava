package Day4.Bank;

public class CopyBankTester {

	public static void main(String[] args) {
		CopyBank cp = new CopyBank(12345, "Mrunali", 10000);
		
		try {
			cp.Display();
			
			double d1 = cp.deposit(5000);
			System.out.println("after deposit bal: "+d1);
			
		}catch(Exception e ) {
			System.out.println(e.getMessage());
		}

	}

}
