package Day4;

public class ArrayOBExp {

	

	public static void main(String[] args) {
		try {
			int arr[]= {1,2,3,4,3,5};
			for(int i=0;i<9;i++) {
			 System.out.println(arr[i]);
			}
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println(e.getMessage()+"ArrayIndexOutOfBoundsException found");
		}finally {
			System.out.println("code exicuted...");
		}

	}

}
