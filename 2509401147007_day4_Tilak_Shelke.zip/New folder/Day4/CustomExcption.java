package Day4;

public class CustomExcption extends Exception{

	public CustomExcption(String Message) {
		super(Message);
	}

}
