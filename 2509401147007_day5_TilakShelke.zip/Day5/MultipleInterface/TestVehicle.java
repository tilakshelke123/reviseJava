package Day5.MultipleInterface;

public class TestVehicle {

	public static void main(String[] args) {
		Vehicle v = new Bicycle();
		Vehicle v1 = new Car();
		
		// Bicycle
		v.startEngine();
		v.stopEngine();
		v.turn("North-East");
		System.out.println("Speed of Bicycle is: "+Bicycle.getTopSpeedLimit(60));
		
		//Car
		v1.startEngine();
		v1.stopEngine();
		v1.turn("North-East");
		System.out.println("Speed of car is: "+Car.getTopSpeedLimit(60));
		

		
		
		C c =  new C();
		c.startEngine();
		c.stopEngine();
	}

}
