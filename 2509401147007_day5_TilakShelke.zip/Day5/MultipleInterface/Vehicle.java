package Day5.MultipleInterface;

public interface Vehicle {
	
	public abstract void  startEngine() ;
	public abstract void  stopEngine() ;
	
	public default void turn(String direction) {
		System.out.println("turn to dircetion to "+direction);

	}
	
	public  static int getTopSpeedLimit(int speed) {
		return speed;
		
	}
}
