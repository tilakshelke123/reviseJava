package Day5.MultipleInterface;

public class C implements Vehicle,Vehicle2{

	@Override
	public void startEngine() {
		System.out.println("start");
		
	}

	@Override
	public void stopEngine() {
		System.out.println("stop");
	}

	@Override
	public void turn(String direction) {
		// TODO Auto-generated method stub
		Vehicle.super.turn(direction);
	}

}
