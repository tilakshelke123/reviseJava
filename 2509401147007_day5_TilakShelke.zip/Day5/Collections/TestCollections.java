package Day5.Collections;

import java.util.ArrayList;

public class TestCollections {

	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<>();

		//  added data 
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		
		//add the data
		list.add(1,6);
		
		//delete the data
		list.remove(4); //  index start from "0" in collections
		list.remove(0);
		

		// print
		for (Integer i : list) {
			System.out.println(i);
		}

		int a=10;
		Integer b=a;
		System.out.println(a);
		System.out.println(b);
	}

}
