package Day5.Interface;

public class TestArea {

	public static void main(String[] args) {
		Shape s1= new Circle("Circle",6);
		Shape s2= new Rectangle("Rectangle",5,9);
		
		s1.displayName();
		System.out.println("Area of circle:"+s1.getArea());
		
		s2.displayName();
		System.out.println("Area of Rectangle:"+s2.getArea());
		
		
	}

}
