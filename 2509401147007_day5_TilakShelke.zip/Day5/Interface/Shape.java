package Day5.Interface;

public abstract class Shape {
	
	String name ;

	public Shape(String name) {
		super();
		this.name = name;
	}
	
	

	public void displayName() {
		
		System.out.println("Shape Name:"+name);
		
	}

	public abstract double getArea();
	
}
