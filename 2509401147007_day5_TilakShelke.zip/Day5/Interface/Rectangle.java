package Day5.Interface;

public class Rectangle extends Shape {
	double length, breadth;

	public Rectangle(String name, double length, double breadth) {
		super(name);
		this.length = length;
		this.breadth = breadth;
	}
@Override
	public double getArea() {
		double area = length * breadth;
		return area;
	}
}
