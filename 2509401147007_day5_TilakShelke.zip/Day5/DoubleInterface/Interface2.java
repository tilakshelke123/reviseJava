package Day5.DoubleInterface;

public interface Interface2 {

		
		public void m2();

	}


