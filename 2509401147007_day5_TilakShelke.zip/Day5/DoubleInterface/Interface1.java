package Day5.DoubleInterface;

public interface Interface1 imlements interface2{
	
	public void m1();

}
